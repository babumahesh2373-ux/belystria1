
import React from 'react';

const Technology: React.FC = () => {
  return null;
};

export default Technology;
