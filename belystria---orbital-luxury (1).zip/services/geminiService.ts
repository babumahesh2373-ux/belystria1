
// Fix: Import GoogleGenAI from @google/genai
import { GoogleGenAI } from "@google/genai";

/**
 * Gemini Service for Belystria Orbital Hotel.
 * Handles AI Concierge interactions and Orbital Imaging Core generation.
 */

// Fix: Updated sendMessageToGemini to accept message and history to match ConciergeBot usage
export const sendMessageToGemini = async (message: string, history: any[] = []) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: "You are the Belystria AI Concierge. You are a professional, sophisticated, and welcoming assistant for the world's first luxury orbital hotel. Provide detailed yet concise information about orbital dynamics, guest amenities, mission tiers, and the science of microgravity. Always maintain a tone of high-end luxury and scientific accuracy.",
      },
    });

    // Fix: Use the .text property (not method) to get response content
    return response.text || "I am currently calibrating my orbital sensors. Please repeat your request.";
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "Transmission error. Please ensure you are connected to the LEO Node 01 gateway.";
  }
};

// Fix: Updated generateSuiteView to accept prompt argument to match ViewVisualizer usage
export const generateSuiteView = async (prompt: string) => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `A hyper-realistic cinematic view through the large circular observation window of the Belystria luxury space hotel. Outside the window: ${prompt}. Visible details include the Earth's curvature, atmosphere glow, and high-tech hotel interior elements. 8k resolution, photorealistic.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9",
        },
      },
    });

    // Fix: Correctly iterate through parts to find the generated image data
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString: string = part.inlineData.data;
          return `data:image/png;base64,${base64EncodeString}`;
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error("Gemini Image Generation Error:", error);
    return null;
  }
};
